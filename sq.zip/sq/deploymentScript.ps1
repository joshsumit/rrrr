﻿Login-azureRMAccount



.\Deploy-AzureResourceGroup1.ps1 `
-ResourceGroupName  testsqlrg `
-ResourceGroupLocation eastus `
-TemplateFile .\ABI.VM.json `
-TemplateParametersFile .\ABI.VM.parameters.json `
-UploadArtifacts


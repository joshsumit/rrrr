Configuration setupsql
{
    param (
        [Parameter(Mandatory = $true)]
        [string]$nodeName        
    )

    Import-DscResource -ModuleName 'PSDesiredStateConfiguration', 'xPendingReboot', 'xStorage'
    $adAdmin='sumit'
    Node ($nodeName)
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'            
        }

        Registry DisableCDROM
        {
            Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\cdrom'
            ValueName = 'Start'
            Ensure = 'Present' 
            Force = $true
            ValueData = '4'
            ValueType = 'Dword'
        }
        WindowsFeature 'Remote Desktop Session Host'
        {
            Name = 'RDS-RD-Server'
            Ensure = 'Present'
            IncludeAllSubFeature = $true
        }
        Script EnableWinrm
        {
            SetScript = {
                Write-Verbose -Message 'Enabling WinRM configurations'
                Set-WSManQuickConfig -Force -SkipNetworkProfileCheck
                eventcreate.exe /t INFORMATION /ID 4 /L APPLICATION /SO 'DSC-Client' /D 'Enabled Windows Remote Management'
            }
            TestScript = {
                try
                {
                    # Use to remove a listener for testing
                    # Remove-WSManInstance winrm/config/Listener -selectorset @{Address="*";Transport="http"}
                    Get-WSManInstance -ResourceURI winrm/config/listener -SelectorSet @{
                        Address   = '*'
                        Transport = 'http'
                    }
                    return $true
                }
                catch 
                {
                    #$wsmanOutput = "WinRM doesn't seem to be configured or enabled."
                    return $false
                }
            }
            GetScript = {
                # Do Nothing
            }
        }
        Script SetSQLSysAdminPermission 
        {
            GetScript = {
                # Do Nothing
            }
            SetScript = {
                Write-Verbose -Message 'Stopping SQL Server Service'
                Stop-Service -Name MSSQLSERVER -Force
                    
                Write-Verbose -Message 'Starting SQL Server Service in Single User Mode'
                Start-Process -FilePath net.exe -ArgumentList 'start MSSQLSERVER /m' -Wait -NoNewWindow
                    
                Write-Verbose -Message "Creating Login $adAdmin"
                Start-Process -FilePath SQLCMD.EXE -ArgumentList "-Q create login [$adAdmin] from windows;" -Wait -NoNewWindow
                    
                Write-Verbose -Message "Assigning SysAdmin access to $adAdmin"
                Start-Process -FilePath SQLCMD.EXE -ArgumentList "-Q alter server role sysadmin add member [$adAdmin];" -Wait -NoNewWindow
                    
                Write-Verbose -Message 'Restarting services'
                Stop-Service -Name MSSQLSERVER -Force
                Start-Service -Name 'MSSQLSERVER', 'SQLSERVERAGENT'
            }
            TestScript = {
                return $false
            }
        }
        Script MovePagefile
        {
            GetScript = {
                # Do Nothing
            }
            TestScript = {
                return $false
            }
            SetScript = {
                Write-Verbose -Message 'Changing Automatic Managed Page File Setting to True'

                Set-CimInstance -Query 'SELECT * FROM Win32_ComputerSystem' -Property @{
                    AutomaticManagedPagefile = $false
                }
                
                Write-Verbose -Message 'Removing current Page Files'                
                Get-CimInstance -Query 'select * from Win32_PageFileSetting' | Remove-CimInstance -Confirm:$false
                
                Write-Verbose -Message 'Creating a new Pagefile in the system drive'

                New-CimInstance -ClassName Win32_PageFileSetting -Property @{
                    name = 'c:\pagefile.sys'
                }
                Write-Verbose -Message 'Changing Pagefile Settings'

                Set-CimInstance -Query "SELECT * FROM Win32_PageFileSetting WHERE SettingID = 'pagefile.sys @ c:'" -Property @{
                    InitialSize = '0'
                    MaximumSize = '0'
                }
            }
        }
        xPendingReboot PageFileValidation
        {
            Name = 'First Rebboot'
            DependsOn = '[Script]MovePagefile'
        } 
        Script MovePageFile2
        {
            GetScript = {
                Result = ''
            }       
            TestScript = {
                return $false
            }
            SetScript = {
                $changedriveletter = $true
                try
                {
                    Write-Verbose -Message 'Changing Temporary Disk DriveLetter'
                    Set-CimInstance -Query "SELECT * FROM Win32_Volume WHERE DriveLetter = 'D:'" -Property @{
                        DriveLetter = 'z:'
                    }
                }
                catch
                {
                    $changedriveletter = $false
                    Write-Verbose -Message "Something went wrong: $($error[0].Exception)"
                }
                if($changedriveletter)
                {
                    Write-Verbose -Message 'Removing Previously Created Page Files'

                    Get-CimInstance -Query 'SELECT * FROM Win32_PageFileSetting' | Remove-CimInstance -Confirm:$false

                    Write-Verbose -Message 'Creating a new Pagefile in the system drive'

                    New-CimInstance -ClassName Win32_PageFileSetting -Property @{
                        name = 'z:\pagefile.sys'
                    }
                
                    Write-Verbose -Message 'Changing Pagefile Settings'

                    Set-CimInstance -Query "SELECT * FROM Win32_PageFileSetting WHERE SettingID = 'pagefile.sys @ z:'" -Property @{
                        InitialSize = '0'
                        MaximumSize = '0'
                    }

                    Write-Verbose -Message 'Changing Automatic Managed Page File Setting to True'
                    Set-CimInstance -Query 'SELECT * FROM Win32_ComputerSystem' -Property @{
                        AutomaticManagedPagefile = $true
                    }
                }
            }
            DependsOn = '[Script]MovePageFile', '[xPendingReboot]PageFileValidation'
        }
        xPendingReboot PageFileValidation2
        {
            Name = 'Second Rebboot'
            DependsOn = '[Script]MovePageFile', '[xPendingReboot]PageFileValidation', '[Script]MovePageFile2'
        }
        xDisk DomainDrive
        {
            DiskNumber = 2
            DriveLetter = 'D'
            DependsOn = '[Script]MovePageFile', '[xPendingReboot]PageFileValidation', '[Script]MovePageFile2', '[xPendingReboot]PageFileValidation2'
            FSLabel = 'DOMAIN'
        }
        Script DATADrive
        {
            GetScript = {
                @{
                    Result = ''
                }
            }
            TestScript = {
            }
            SetScript = {
                $StoragePoolName = "$($env:COMPUTERNAME)-sp"
                $VirtualDiskName = "$($env:COMPUTERNAME)-vd"
            
                Write-Verbose -Message 'Changing the System Drive Lavel'
                Set-Volume -DriveLetter C -NewFileSystemLabel SYSTEM
                                
                if((Get-StoragePool).FriendlyName.count -le 1)
                {
                    Write-Verbose -Message 'Creating Storage Pool'

                    $StoragePool = @{
                        FriendlyName             = $StoragePoolName
                        StorageSubSystemUniqueId = (Get-StorageSubSystem -FriendlyName '*Spaces*').UniqueId
                        PhysicalDisks            = (Get-PhysicalDisk -CanPool $true)
                    }
 
                    New-StoragePool @StoragePool
                }
                            
                Write-Verbose -Message 'Creating Virtual Disk'
                
                if((Get-VirtualDisk).FriendlyName.count -le 0)
                {
                    $VirtualDisk = @{
                        FriendlyName            = $VirtualDiskName
                        StoragePoolFriendlyName = $StoragePoolName
                        ResiliencySettingName   = 'Simple'
                        UseMaximumSize          = $true
                    }

                    New-VirtualDisk @VirtualDisk
       			
                    Write-Verbose -Message 'Initializing Disk'

                    Initialize-Disk -VirtualDisk (Get-VirtualDisk -FriendlyName $VirtualDiskName)
                }

                if(-not(Test-Path 'G:\'))
                {
                    $diskNumber = ((Get-VirtualDisk -FriendlyName $VirtualDiskName | Get-Disk).Number)
        
                    Write-Verbose -Message 'Creating Partition'

                    $Partition = @{
                        DiskNumber     = $diskNumber
                        UseMaximumSize = $true
                        DriveLetter    = 'G'
                    }
                    New-Partition @Partition
                    
                    Write-Verbose -Message 'Formatting Volume and Assigning Drive Letter'
                    
                    $Volume = @{
                        DriveLetter        = 'G'
                        FileSystem         = 'NTFS'
                        NewFileSystemLabel = 'DATA'
                        Confirm            = $false
                        Force              = $true
                    }
                    Format-Volume @Volume

                    Set-Volume -DriveLetter 'G' -NewFileSystemLabel 'DATA' -Verbose -Confirm:$false
                }
            }
            DependsOn = '[Script]MovePageFile', '[xPendingReboot]PageFileValidation', '[Script]MovePageFile2', '[xPendingReboot]PageFileValidation2', '[xDisk]DomainDrive'
        }
        xPendingReboot xDataDrive 
        {
            Name = 'Third Reboot'
            DependsOn = '[Script]MovePageFile', '[xPendingReboot]PageFileValidation', '[Script]MovePageFile2', '[xPendingReboot]PageFileValidation2', '[xDisk]DomainDrive', '[Script]DATADrive'
        }
        Script SQLServerConfiguration 
        {
            GetScript = {

            }
            SetScript = {
                Write-Verbose -Message 'Creating folder G:\MSSQL'
                New-Item -Path 'G:\MSSQL' -ItemType Directory -Force

                Write-Verbose -Message 'Creating folder G:\MSSQL\Data'
                New-Item -Path 'G:\MSSQL\Data' -ItemType Directory -Force

                Write-Verbose -Message 'Creating folder G:\MSSQL\Logs'
                New-Item -Path 'G:\MSSQL\Logs' -ItemType Directory -Force

                Write-Verbose -Message 'Creating folder G:\MSSQL\Backups'
                New-Item -Path 'G:\MSSQL\Backups' -ItemType Directory -Force
                
                Write-Verbose -Message 'Changing SQLSERVERAGENT Service to Automatic Startup'
                Set-Service -Name 'SQLSERVERAGENT' -StartupType Automatic

                Write-Verbose -Message 'Stopping SQL Server Service'
                Stop-Service -Name MSSQLSERVER -Force
                    
                Write-Verbose -Message 'Starting SQL Server Service in Single User Mode'
                Start-Process -FilePath net.exe -ArgumentList 'start MSSQLSERVER /m' -Wait -NoNewWindow
                    
                Write-Verbose -Message 'Changing SQL Server Database Folder to G:\MSSQL\Data'
                Start-Process -FilePath SQLCMD.EXE -ArgumentList "-Q EXEC   xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer',N'DefaultData',REG_SZ,N'G:\MSSQL\Data'" -Wait -NoNewWindow
                    
                Write-Verbose -Message 'Changing SQL Server Logs Folder to G:\MSSQL\Logs'
                Start-Process -FilePath SQLCMD.EXE -ArgumentList "-Q EXEC   xp_instance_regwrite N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\MSSQLServer',N'DefaultLog',REG_SZ,N'G:\MSSQL\Logs'" -Wait -NoNewWindow

                Write-Verbose -Message 'Changing SQL Server Backup Folder to G:\MSSQL\Backups'
                Start-Process -FilePath SQLCMD.EXE -ArgumentList "-Q EXEC   EXEC   xp_instance_regwrite N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\MSSQLServer',N'BackupDirectory', REG_SZ, N'G:\MSSQL\Backups'" -Wait -NoNewWindow
                    
                Write-Verbose -Message 'Restarting services'
                Stop-Service -Name MSSQLSERVER -Force
                Start-Service -Name 'MSSQLSERVER', 'SQLSERVERAGENT'
            }
            TestScript = {

            }
            DependsOn = '[Script]MovePageFile', '[xPendingReboot]PageFileValidation', '[Script]MovePageFile2', '[xPendingReboot]PageFileValidation2', '[xDisk]DomainDrive', '[Script]DATADrive', '[xPendingReboot]xDataDrive'
        }
    }
}


